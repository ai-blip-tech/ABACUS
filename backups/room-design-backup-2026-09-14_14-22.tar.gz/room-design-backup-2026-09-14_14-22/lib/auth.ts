import { env } from "cloudflare:workers";

export type AppUser = { id: string; email: string; role: "user" | "admin" };

const encoder = new TextEncoder();
const b64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
const fromB64 = (value: string) => Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), (character) => character.charCodeAt(0));
const randomValue = () => b64(crypto.getRandomValues(new Uint8Array(32)));
const sha256 = async (value: string) => b64(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value))));

async function passwordHash(password: string, salt = randomValue()) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  // Cloudflare Workers limits PBKDF2 to 100,000 iterations.  This remains a
  // deliberately slow, salted password hash while being supported at runtime.
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: fromB64(salt), iterations: 100_000, hash: "SHA-256" }, key, 256);
  return { salt, hash: b64(new Uint8Array(bits)) };
}

const equal = (left: string, right: string) => {
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let index = 0; index < left.length; index += 1) diff |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return diff === 0;
};

const d1 = () => {
  if (!env.DB) throw new Error("Хранилище аккаунтов пока недоступно.");
  return env.DB;
};

let setup: Promise<void> | null = null;
export function ensureStore() {
  if (setup) return setup;
  const database = d1();
  setup = (async () => {
    await database.batch([
      database.prepare("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL COLLATE NOCASE UNIQUE, password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL, last_login_at TEXT)"),
      database.prepare("CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)"),
      database.prepare("CREATE TABLE IF NOT EXISTS generations (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, operation TEXT NOT NULL, prompt TEXT, output_key TEXT NOT NULL, content_type TEXT NOT NULL, bytes INTEGER NOT NULL DEFAULT 0, input_tokens INTEGER, output_tokens INTEGER, total_tokens INTEGER, created_at TEXT NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)"),
      database.prepare("CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash)"),
      database.prepare("CREATE INDEX IF NOT EXISTS idx_generations_user_created_at ON generations(user_id, created_at DESC)"),
      database.prepare("CREATE INDEX IF NOT EXISTS idx_generations_created_at ON generations(created_at DESC)"),
    ]);
    const adminEmail = (env.ADMIN_EMAIL || "").trim().toLowerCase();
    const adminPassword = env.ADMIN_PASSWORD || "";
    if (!adminEmail || !adminPassword) return;
    const existing = await database.prepare("SELECT id FROM users WHERE email = ?").bind(adminEmail).first<{ id: string }>();
    if (!existing) {
      const password = await passwordHash(adminPassword);
      await database.prepare("INSERT INTO users (id, email, password_hash, password_salt, role, created_at) VALUES (?, ?, ?, ?, 'admin', ?)").bind(crypto.randomUUID(), adminEmail, password.hash, password.salt, new Date().toISOString()).run();
    } else {
      await database.prepare("UPDATE users SET role = 'admin' WHERE id = ?").bind(existing.id).run();
    }
  })();
  return setup;
}

export const sessionCookie = (token: string) => `room_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${60 * 60 * 24 * 14}`;
export const clearSessionCookie = "room_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";

function cookieValue(request: Request) {
  const cookie = request.headers.get("cookie") || "";
  return cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith("room_session="))?.slice("room_session=".length) || "";
}

export async function currentUser(request: Request): Promise<AppUser | null> {
  await ensureStore();
  const token = cookieValue(request);
  if (!token) return null;
  const row = await d1().prepare("SELECT users.id, users.email, users.role FROM sessions JOIN users ON users.id = sessions.user_id WHERE sessions.token_hash = ? AND sessions.expires_at > ?").bind(await sha256(token), new Date().toISOString()).first<AppUser>();
  return row ? { ...row, role: row.role === "admin" ? "admin" : "user" } : null;
}

export async function register(email: string, password: string) {
  await ensureStore();
  const normalized = email.trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(normalized)) throw new Error("Укажите корректный email.");
  if (password.length < 8) throw new Error("Пароль должен содержать не менее 8 символов.");
  const existing = await d1().prepare("SELECT id FROM users WHERE email = ?").bind(normalized).first();
  if (existing) throw new Error("Этот email уже зарегистрирован. Войдите в аккаунт.");
  const secured = await passwordHash(password);
  const configuredAdmin = (env.ADMIN_EMAIL || "").trim().toLowerCase();
  const user: AppUser = { id: crypto.randomUUID(), email: normalized, role: normalized === configuredAdmin ? "admin" : "user" };
  await d1().prepare("INSERT INTO users (id, email, password_hash, password_salt, role, created_at, last_login_at) VALUES (?, ?, ?, ?, ?, ?, ?)").bind(user.id, user.email, secured.hash, secured.salt, user.role, new Date().toISOString(), new Date().toISOString()).run();
  return user;
}

export async function login(email: string, password: string) {
  await ensureStore();
  const user = await d1().prepare("SELECT id, email, role, password_hash, password_salt FROM users WHERE email = ?").bind(email.trim().toLowerCase()).first<AppUser & { password_hash: string; password_salt: string }>();
  if (!user) throw new Error("Неверный email или пароль.");
  const secured = await passwordHash(password, user.password_salt);
  if (!equal(secured.hash, user.password_hash)) throw new Error("Неверный email или пароль.");
  await d1().prepare("UPDATE users SET last_login_at = ? WHERE id = ?").bind(new Date().toISOString(), user.id).run();
  return { id: user.id, email: user.email, role: user.role === "admin" ? "admin" as const : "user" as const };
}

export async function createSession(userId: string) {
  await ensureStore();
  const token = randomValue();
  const now = new Date();
  const expires = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);
  await d1().prepare("INSERT INTO sessions (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)").bind(crypto.randomUUID(), userId, await sha256(token), expires.toISOString(), now.toISOString()).run();
  return token;
}

export async function deleteSession(request: Request) {
  const token = cookieValue(request);
  if (token) await d1().prepare("DELETE FROM sessions WHERE token_hash = ?").bind(await sha256(token)).run();
}

export async function requireAdmin(request: Request) {
  const user = await currentUser(request);
  if (!user || user.role !== "admin") return null;
  return user;
}

export async function recordGeneration(user: AppUser, values: { operation: string; prompt: string; outputKey: string; contentType: string; bytes: number; inputTokens?: number | null; outputTokens?: number | null; totalTokens?: number | null }) {
  await ensureStore();
  await d1().prepare("INSERT INTO generations (id, user_id, operation, prompt, output_key, content_type, bytes, input_tokens, output_tokens, total_tokens, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").bind(crypto.randomUUID(), user.id, values.operation, values.prompt.slice(0, 2000), values.outputKey, values.contentType, values.bytes, values.inputTokens ?? null, values.outputTokens ?? null, values.totalTokens ?? null, new Date().toISOString()).run();
}

export function storage() {
  if (!env.GENERATIONS) throw new Error("Хранилище результатов генераций пока недоступно.");
  return env.GENERATIONS;
}
