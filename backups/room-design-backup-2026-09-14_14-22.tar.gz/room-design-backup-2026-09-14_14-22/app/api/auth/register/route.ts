import { createSession, register, sessionCookie } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const body = await request.json() as { email?: string; password?: string };
    const user = await register(body.email || "", body.password || "");
    const token = await createSession(user.id);
    return Response.json({ user }, { headers: { "Set-Cookie": sessionCookie(token) } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Не удалось создать аккаунт." }, { status: 400 });
  }
}
