import { env } from "cloudflare:workers";
import { ensureStore, requireAdmin } from "@/lib/auth";

const INPUT_USD_PER_MILLION = 8;
const OUTPUT_USD_PER_MILLION = 30;

export async function GET(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return Response.json({ error: "Недостаточно прав." }, { status: 403 });
  await ensureStore();
  const users = await env.DB.prepare(`
    SELECT users.id, users.email, users.role, users.created_at, users.last_login_at,
      COUNT(generations.id) AS generations,
      COALESCE(SUM(generations.input_tokens), 0) AS input_tokens,
      COALESCE(SUM(generations.output_tokens), 0) AS output_tokens,
      COALESCE(SUM(generations.total_tokens), 0) AS tokens,
      (COALESCE(SUM(generations.input_tokens), 0) * ${INPUT_USD_PER_MILLION} + COALESCE(SUM(generations.output_tokens), 0) * ${OUTPUT_USD_PER_MILLION}) / 1000000.0 AS cost_usd
    FROM users LEFT JOIN generations ON generations.user_id = users.id
    GROUP BY users.id ORDER BY users.created_at DESC
  `).all();
  const generations = await env.DB.prepare(`
    SELECT generations.id, generations.operation, generations.prompt, generations.bytes,
      generations.input_tokens, generations.output_tokens, generations.total_tokens,
      generations.created_at, users.email,
      (COALESCE(generations.input_tokens, 0) * ${INPUT_USD_PER_MILLION} + COALESCE(generations.output_tokens, 0) * ${OUTPUT_USD_PER_MILLION}) / 1000000.0 AS cost_usd
    FROM generations JOIN users ON users.id = generations.user_id
    ORDER BY generations.created_at DESC LIMIT 100
  `).all();
  return Response.json({ users: users.results, generations: generations.results });
}
